// script.js
// Paste the JS content from previous script_js doc here
